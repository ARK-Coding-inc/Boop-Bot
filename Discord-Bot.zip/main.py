import os
import discord
from discord.ext import commands
from keep_alive import keep_alive
import random
import csv
import pandas as pd
from datetime import datetime
import pytz

quote = [] #array for data to stored in
bot = commands.Bot(command_prefix="!", intents=discord.Intents.all()) #connecting to discord API

@bot.event
async def on_ready():
  print('We have logged in as {0.user}'.format(bot))
  for guild in bot.guilds:
        print(guild.name)
#################################################################

#Function to save all quotes from csv into an array 
def get_quote():
  global quote
  with open ("Quotes.csv") as csv_file:
    csv_reader = csv.reader(csv_file)
    for row in csv_reader:  
      quote.append(row)
  
get_quote()

#handle error with spam and display cooldown msg
@bot.event
async def on_command_error(ctx, error):
	if isinstance(error, commands.CommandOnCooldown):
		await ctx.send(f"{round(error.retry_after, 2)} seconds left")

@bot.command()
@commands.cooldown(1, 5, commands.BucketType.user)
async def boop(ctx):
    # Find the most recent Quotes file
    quotes_files = [f for f in os.listdir() if f.startswith("Quotes_") and f.endswith(".txt")]
    if not quotes_files:
        await ctx.send("No quotes file found.")
        return

    # Sort files by date extracted from filename in descending order to get the latest file
    quotes_files.sort(key=lambda f: datetime.strptime(f[7:-4], "%d_%m_%Y"), reverse=True)
    latest_file = quotes_files[0]

    # Read quotes from the latest file
    with open(latest_file, 'r', encoding='utf-8') as f:
        quotes = [line.strip() for line in f if line.strip()]

    # Select a random quote
    if quotes:
        chosen_quote = random.choice(quotes)
        print(chosen_quote)
        await ctx.channel.send(chosen_quote)
    else:
        await ctx.send("No quotes available in the latest file.")






@bot.command()
@commands.cooldown(1, 5, commands.BucketType.user)
async def save(ctx):
      # Delete the user's !save message
      await ctx.message.delete()

      print("Saving...")
      messages = []

      # Collect messages, filtering out bot commands, bot messages, and blank lines within each message
      async for msg in ctx.channel.history(limit=1000):  # Adjust limit as needed
          if msg.content and not msg.content.startswith("!") and msg.author != bot.user:
              # Split message by lines, remove blank lines, and reassemble
              lines = [line.strip() for line in msg.content.splitlines() if line.strip()]
              if lines:  # Only add if there is content after filtering
                  cleaned_message = "\n".join(lines)
                  messages.append(cleaned_message)

      # Get Australian Eastern Time (Sydney Time)
      aust_time = pytz.timezone('Australia/Sydney')
      current_date = datetime.now(aust_time).strftime("%d_%m_%Y")
      print(current_date)

      # Generate file name with current date in dd_mm_yyyy format
      file_location = f"Quotes_{current_date}.txt"

      # Write cleaned messages to the dynamically named text file
      with open(file_location, 'w', encoding='utf-8') as f:
          for message in messages:
              f.write(message + "\n")  # Write each message, separated by a blank line for readability

      print("Successfully saved!")

      # Get the guild and channel using the provided IDs
      guild_id = 1306551380789432370
      channel_id = 1307684427828166756
      guild = bot.get_guild(guild_id)
      target_channel = guild.get_channel(channel_id)

      # Check if the channel was found and send the file
      if target_channel:
          # Send the file to the specified channel
          with open(file_location, 'rb') as file:
              await target_channel.send("Here's the saved quotes file:", file=discord.File(file, file_location))

          # Send confirmation message to the user and delete it after 5 seconds
          confirmation_message = await ctx.send("Successfully saved!")
          await confirmation_message.delete(delay=1)
      else:
          print("Channel not found. Please check the channel ID.")



  


    







  
#################################################################


@bot.command()
async def servers(ctx):
    embed = discord.Embed(title='Server List', description='List of servers that the bot is in:')
    for guild in bot.guilds:
        embed.add_field(name=guild.name, value='\u200b', inline=False)
    await ctx.send(embed=embed)


keep_alive()
my_secret = os.environ['token']
bot.run(my_secret)
